# FiveM-Bot-Detection
This script allows you to find out how many bots there are on a fivem server from the cfx code.

1) Put your steam api in the "api_key" variable, which can be obtained from the following site: https://steamcommunity.com/dev/apikey
2) Run the script as follows: python3 fivembotdetection.py "cfxcode"
